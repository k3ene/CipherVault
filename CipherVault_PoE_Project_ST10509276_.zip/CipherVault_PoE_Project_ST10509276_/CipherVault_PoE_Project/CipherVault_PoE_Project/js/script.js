
document.addEventListener("DOMContentLoaded",()=>{
 const page=document.body.dataset.page;
 document.querySelectorAll(".nav-links a").forEach(a=>{
   if((page==="index"&&a.getAttribute("href")==="index.html")||(page==="about"&&a.getAttribute("href")==="about.html")||(page==="services"&&a.getAttribute("href")==="services.html")||(page==="enquiry"&&a.getAttribute("href")==="enquiry.html")||(page==="contact"&&a.getAttribute("href")==="contact.html")) a.classList.add("active");
 });
 const toggle=document.querySelector(".menu-toggle"),nav=document.querySelector(".nav-links");
 if(toggle) toggle.addEventListener("click",()=>{const open=nav.classList.toggle("open");toggle.setAttribute("aria-expanded",open)});
 // Close the mobile menu automatically once a link is tapped
 if(nav) nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");if(toggle)toggle.setAttribute("aria-expanded",false)}));
 const search=document.getElementById("serviceSearch"), cards=[...document.querySelectorAll(".service-card")], no=document.getElementById("noResults");
 if(search) search.addEventListener("input",()=>{let term=search.value.toLowerCase().trim(),count=0;cards.forEach(c=>{let ok=c.dataset.search.includes(term);c.classList.toggle("hidden",!ok);if(ok)count++});no.classList.toggle("hidden",count>0)});
 const params=new URLSearchParams(location.search), svc=params.get("service"), select=document.getElementById("enqService"); if(select&&svc)select.value=svc;
 function handle(form,response,msg){form.addEventListener("submit",e=>{e.preventDefault();if(!form.checkValidity()){response.textContent="Please complete all required fields correctly.";response.className="form-response error";form.reportValidity();return}response.textContent=msg;response.className="form-response success";form.reset()})}
 const ef=document.getElementById("enquiryForm"); if(ef)handle(ef,document.getElementById("enquiryResponse"),"Thank you. Your enquiry has been recorded for this project demonstration.");
 const cf=document.getElementById("contactForm"); if(cf)handle(cf,document.getElementById("contactResponse"),"Thank you. Your message has been recorded for this project demonstration.");

 // Subtle fade/rise-in for cards as they enter the viewport (skipped if the user prefers reduced motion)
 const reduceMotion=window.matchMedia("(prefers-reduced-motion: reduce)").matches;
 const revealTargets=[...document.querySelectorAll(".card, .person, .location-card")];
 if(!reduceMotion && "IntersectionObserver" in window && revealTargets.length){
   revealTargets.forEach(el=>el.classList.add("reveal"));
   const io=new IntersectionObserver(entries=>{
     entries.forEach(entry=>{
       if(entry.isIntersecting){entry.target.classList.add("reveal-in");io.unobserve(entry.target)}
     });
   },{threshold:0.15});
   revealTargets.forEach(el=>io.observe(el));
 }
});
