/* =============================================================
   CipherVault Tech Solutions - data.js (Part 3)
   Single source of truth for the services catalogue, security
   tips and pricing rules. script.js reads these arrays to build
   the Services page, the enquiry drop-down, the quote calculator
   and the home page tip. All prices are fictional (ZAR, excl. VAT).
   ============================================================= */

// Pricing rule used by the enquiry quote:
//   price = base + (quantity - included) x perUnit   (never below base)
const SERVICES = [
  {
    id: "consulting",
    name: "Cybersecurity Consulting",
    category: "Consulting",
    summary: "Guidance to review security practices and identify practical improvements.",
    details: "One-to-one or team sessions where we review how you currently protect accounts, devices and data, then agree a short, realistic action list.",
    includes: ["Review of current security habits", "Prioritised action list in plain language", "Follow-up email summary"],
    keywords: "consulting consultant advice guidance review strategy policy",
    base: 1200, included: 1, perUnit: 1000, unitSingular: "session", unitPlural: "sessions", leadDays: 3
  },
  {
    id: "training",
    name: "Security Awareness Training",
    category: "Training",
    summary: "Training focused on phishing, passwords, social engineering and safer online behaviour.",
    details: "A practical workshop that teaches staff or students how to spot phishing, scams and unsafe habits, using real-world examples rather than jargon.",
    includes: ["Interactive workshop (up to 10 people)", "Phishing spotting checklist", "Short quiz to confirm understanding"],
    keywords: "training awareness phishing social engineering workshop staff students learn",
    base: 2500, included: 10, perUnit: 150, unitSingular: "participant", unitPlural: "participants", leadDays: 7
  },
  {
    id: "assessment",
    name: "Digital Risk Assessment",
    category: "Assessment",
    summary: "A structured review of common digital risks and prioritised recommendations.",
    details: "A structured check of devices, accounts and settings that produces a ranked list of risks with simple fixes, so you know what to tackle first.",
    includes: ["Review of up to 5 devices", "Account and settings checklist", "Written risk report with priorities"],
    keywords: "risk assessment audit review devices vulnerabilities report",
    base: 3800, included: 5, perUnit: 250, unitSingular: "device", unitPlural: "devices", leadDays: 10
  },
  {
    id: "passwords",
    name: "Password Security Guidance",
    category: "Guidance",
    summary: "Advice on strong passwords, password managers and multi-factor authentication.",
    details: "Hands-on help to move from reused passwords to a password manager and multi-factor authentication on your most important accounts.",
    includes: ["Password manager set-up help (up to 3 users)", "Multi-factor authentication walkthrough", "Account recovery checklist"],
    keywords: "password passwords authentication mfa 2fa manager login accounts",
    base: 650, included: 3, perUnit: 100, unitSingular: "user", unitPlural: "users", leadDays: 2
  },
  {
    id: "backup",
    name: "Secure Backup Advice",
    category: "Guidance",
    summary: "Guidance for reliable backup routines and reducing the impact of data loss.",
    details: "We help you choose and test a simple backup routine so that a lost laptop, failed drive or ransomware attack does not mean losing everything.",
    includes: ["Backup plan for up to 3 devices", "Cloud and offline backup options explained", "Restore test checklist"],
    keywords: "backup cloud data recovery ransomware restore storage",
    base: 900, included: 3, perUnit: 120, unitSingular: "device", unitPlural: "devices", leadDays: 3
  }
];

// Discount applied per client type, and the rush surcharge for priority bookings.
const CLIENT_DISCOUNTS = { individual: 0.10, business: 0, nonprofit: 0.15 };
const CLIENT_LABELS = { individual: "Individual / student", business: "Small business", nonprofit: "Non-profit / school" };
const PRIORITY_SURCHARGE = 0.25;
const VAT_RATE = 0.15;

// Short original tips shown on the home page.
const SECURITY_TIPS = [
  "Use a different password for every account. A password manager makes this realistic.",
  "Turn on multi-factor authentication for email first - email resets every other account.",
  "Pause before clicking links in urgent messages. Go to the website yourself instead.",
  "Keep phones and laptops updated. Updates often fix security holes attackers already know about.",
  "Follow the 3-2-1 idea for backups: three copies, two types of storage, one kept off-site.",
  "Public Wi-Fi is fine for browsing, but avoid banking or admin logins on it."
];
