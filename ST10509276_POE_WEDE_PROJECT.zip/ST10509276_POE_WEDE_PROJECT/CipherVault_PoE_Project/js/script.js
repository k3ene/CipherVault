/* =============================================================
   CipherVault Tech Solutions - script.js (Part 3)
   Sections:
     1. Helpers
     2. Navigation
     3. Services page: dynamic cards, search, filter, sort, modal
     4. Interactive components: accordion, tabs, gallery lightbox
     5. Home page: rotating security tip
     6. Form validation framework
     7. Enquiry form: quote calculation + availability response
     8. Contact form: compiles an email the visitor can send
     9. Contact page: interactive Leaflet map
    10. Scroll reveal animation
   ============================================================= */
"use strict";

/* ---------- Settings you may need to change ---------- */
// Each office has its own recipient. Change these to your own address
// while testing so that you can confirm the email really opens.
const OFFICE_EMAILS = {
  Johannesburg: "hello@ciphervault.co.za",
  Pretoria: "pretoria@ciphervault.co.za"
};

/* ============================ 1. HELPERS ============================ */

// Shorthand for querying the DOM.
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

// Builds an element safely (text is set with textContent, never innerHTML,
// so user-supplied text can never be interpreted as HTML).
function el(tag, options = {}, ...children) {
  const node = document.createElement(tag);
  if (options.class) node.className = options.class;
  if (options.text) node.textContent = options.text;
  if (options.attrs) {
    Object.entries(options.attrs).forEach(([name, value]) => node.setAttribute(name, value));
  }
  children.forEach(child => child && node.append(child));
  return node;
}

// Formats a number as South African rand, e.g. 1200 -> "R1 200.00".
function money(amount, decimals = 2) {
  const [whole, cents] = amount.toFixed(decimals).split(".");
  const spaced = whole.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return "R" + spaced + (cents ? "." + cents : "");
}

// Converts "YYYY-MM-DD" (from a date input) into a local Date, or null if invalid.
function parseDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;
  const date = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  return date.getMonth() === Number(match[2]) - 1 ? date : null; // rejects e.g. 31 Feb
}

function startOfToday() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate());
}

function toInputDate(date) {
  const pad = n => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

function isWeekend(date) {
  return date.getDay() === 0 || date.getDay() === 6;
}

// Adds working days (Monday-Friday) to a date.
function addBusinessDays(start, days) {
  const result = new Date(start);
  let added = 0;
  while (added < days) {
    result.setDate(result.getDate() + 1);
    if (!isWeekend(result)) added++;
  }
  return result;
}

function longDate(date) {
  return date.toLocaleDateString("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

/* ============================ 2. NAVIGATION ============================ */
function initNavigation() {
  const page = document.body.dataset.page;
  const toggle = $(".menu-toggle");
  const nav = $(".nav-links");

  // Highlight the link for the current page.
  $$(".nav-links a").forEach(link => {
    if (link.getAttribute("href") === `${page}.html`) {
      link.classList.add("active");
      link.setAttribute("aria-current", "page");
    }
  });

  if (!toggle || !nav) return;

  const setOpen = open => {
    nav.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  };

  toggle.addEventListener("click", () => setOpen(!nav.classList.contains("open")));
  // Close the mobile menu after a link is tapped, or when Escape is pressed.
  $$("a", nav).forEach(link => link.addEventListener("click", () => setOpen(false)));
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && nav.classList.contains("open")) {
      setOpen(false);
      toggle.focus();
    }
  });
}

/* ================ 3. SERVICES PAGE (DYNAMIC CONTENT) ================ */
function initServices() {
  const grid = $("#serviceGrid");
  if (!grid || typeof SERVICES === "undefined") return;

  const searchInput = $("#serviceSearch");
  const categorySelect = $("#serviceCategory");
  const sortSelect = $("#serviceSort");
  const countText = $("#resultCount");
  const noResults = $("#noResults");
  const resetButton = $("#resetFilters");
  const modal = $("#serviceModal");

  // Fill the category filter from the data (no duplicated lists in the HTML).
  [...new Set(SERVICES.map(s => s.category))].sort().forEach(category => {
    categorySelect.append(el("option", { text: category, attrs: { value: category } }));
  });

  // Returns the services that match the current search, filter and sort.
  function getVisibleServices() {
    const words = searchInput.value.toLowerCase().trim().split(/\s+/).filter(Boolean);
    let list = SERVICES.filter(service => {
      const haystack = [service.name, service.category, service.summary, service.keywords, service.includes.join(" ")]
        .join(" ").toLowerCase();
      const matchesSearch = words.every(word => haystack.includes(word)); // every word must appear
      const matchesCategory = categorySelect.value === "all" || service.category === categorySelect.value;
      return matchesSearch && matchesCategory;
    });

    const sorters = {
      "name-asc": (a, b) => a.name.localeCompare(b.name),
      "name-desc": (a, b) => b.name.localeCompare(a.name),
      "price-asc": (a, b) => a.base - b.base,
      "price-desc": (a, b) => b.base - a.base
    };
    if (sorters[sortSelect.value]) list = [...list].sort(sorters[sortSelect.value]);
    return list;
  }

  function buildCard(service) {
    const enquireLink = el("a", {
      class: "btn btn-primary",
      text: "Enquire",
      attrs: { href: `enquiry.html?service=${encodeURIComponent(service.name)}` }
    });
    enquireLink.setAttribute("aria-label", `Enquire about ${service.name}`);

    const detailsButton = el("button", {
      class: "btn btn-outline",
      text: "Details",
      attrs: { type: "button", "data-id": service.id, "aria-haspopup": "dialog" }
    });

    return el("article", { class: "card service-card" },
      el("span", { class: "pill", text: service.category }),
      el("h2", { text: service.name }),
      el("p", { text: service.summary }),
      el("p", { class: "price", text: `From ${money(service.base, 0)} per booking` }),
      el("div", { class: "card-actions" }, detailsButton, enquireLink)
    );
  }

  function render() {
    const list = getVisibleServices();
    grid.replaceChildren(...list.map(buildCard));
    noResults.classList.toggle("hidden", list.length > 0);
    countText.textContent = list.length === SERVICES.length
      ? `Showing all ${list.length} services`
      : `Showing ${list.length} of ${SERVICES.length} services`;
  }

  function openModal(service) {
    $("#modalTitle", modal).textContent = service.name;
    $("#modalCategory", modal).textContent = service.category;
    $("#modalDetails", modal).textContent = service.details;
    $("#modalIncludes", modal).replaceChildren(...service.includes.map(item => el("li", { text: item })));
    $("#modalPrice", modal).textContent =
      `${money(service.base, 0)} covers up to ${service.included} ${service.included === 1 ? service.unitSingular : service.unitPlural}; ` +
      `each extra ${service.unitSingular} adds ${money(service.perUnit, 0)} (excl. VAT).`;
    $("#modalLead", modal).textContent = `Typical availability: about ${service.leadDays} working days after booking.`;
    $("#modalEnquire", modal).setAttribute("href", `enquiry.html?service=${encodeURIComponent(service.name)}`);
    if (typeof modal.showModal === "function") modal.showModal();
  }

  // One listener handles every "Details" button, even after re-rendering.
  grid.addEventListener("click", event => {
    const button = event.target.closest("button[data-id]");
    if (!button) return;
    const service = SERVICES.find(s => s.id === button.dataset.id);
    if (service) openModal(service);
  });

  if (modal) {
    $(".modal-close", modal).addEventListener("click", () => modal.close());
    // Clicking the dark backdrop (outside the dialog box) closes the modal.
    modal.addEventListener("click", event => { if (event.target === modal) modal.close(); });
  }

  [searchInput, categorySelect, sortSelect].forEach(control => {
    control.addEventListener("input", render);
    control.addEventListener("change", render);
  });
  resetButton.addEventListener("click", () => {
    searchInput.value = "";
    categorySelect.value = "all";
    sortSelect.value = "default";
    render();
    searchInput.focus();
  });

  render();
}

/* ============ 4. INTERACTIVE COMPONENTS: ACCORDION, TABS, LIGHTBOX ============ */

// Accordion: each button toggles the panel it controls. Only one is open at a time.
function initAccordions() {
  $$("[data-accordion]").forEach(accordion => {
    const buttons = $$(".accordion-button", accordion);
    buttons.forEach(button => {
      button.addEventListener("click", () => {
        const willOpen = button.getAttribute("aria-expanded") !== "true";
        buttons.forEach(other => {
          other.setAttribute("aria-expanded", "false");
          document.getElementById(other.getAttribute("aria-controls")).hidden = true;
        });
        if (willOpen) {
          button.setAttribute("aria-expanded", "true");
          document.getElementById(button.getAttribute("aria-controls")).hidden = false;
        }
      });
    });
  });
}

// Tabs: click or use the arrow keys / Home / End to move between tabs.
function initTabs() {
  $$("[data-tabs]").forEach(group => {
    const tabs = $$('[role="tab"]', group);

    function select(tab, moveFocus) {
      tabs.forEach(other => {
        const active = other === tab;
        other.setAttribute("aria-selected", String(active));
        other.tabIndex = active ? 0 : -1;
        document.getElementById(other.getAttribute("aria-controls")).hidden = !active;
      });
      if (moveFocus) tab.focus();
    }

    tabs.forEach((tab, index) => {
      tab.addEventListener("click", () => select(tab, false));
      tab.addEventListener("keydown", event => {
        const lastIndex = tabs.length - 1;
        const moves = {
          ArrowRight: index === lastIndex ? 0 : index + 1,
          ArrowLeft: index === 0 ? lastIndex : index - 1,
          Home: 0,
          End: lastIndex
        };
        if (event.key in moves) {
          event.preventDefault();
          select(tabs[moves[event.key]], true);
        }
      });
    });
  });
}

// Gallery lightbox: thumbnails are normal links (work without JavaScript);
// with JavaScript they open a larger view with previous/next controls.
function initGallery() {
  const items = $$(".gallery-item");
  const box = $("#lightbox");
  if (!items.length || !box) return;

  const image = $(".lightbox-image", box);
  const caption = $(".lightbox-caption", box);
  const counter = $(".lightbox-counter", box);
  let current = 0;

  function show(index) {
    current = (index + items.length) % items.length; // wraps around at both ends
    const item = items[current];
    const thumb = $("img", item);
    image.src = item.getAttribute("href");
    image.alt = thumb.alt;
    caption.textContent = item.dataset.caption || thumb.alt;
    counter.textContent = `${current + 1} of ${items.length}`;
  }

  items.forEach((item, index) => {
    item.addEventListener("click", event => {
      event.preventDefault();
      show(index);
      if (typeof box.showModal === "function") box.showModal();
    });
  });

  $(".lightbox-prev", box).addEventListener("click", () => show(current - 1));
  $(".lightbox-next", box).addEventListener("click", () => show(current + 1));
  $(".lightbox-close", box).addEventListener("click", () => box.close());
  box.addEventListener("click", event => { if (event.target === box) box.close(); });
  box.addEventListener("keydown", event => {
    if (event.key === "ArrowLeft") show(current - 1);
    if (event.key === "ArrowRight") show(current + 1);
  });
}

/* ================ 5. HOME PAGE: ROTATING SECURITY TIP ================ */
function initTip() {
  const text = $("#tipText");
  const button = $("#tipButton");
  if (!text || !button || typeof SECURITY_TIPS === "undefined") return;

  // Start with a tip that changes daily, then cycle on each click.
  const dayOfYear = Math.floor((startOfToday() - new Date(startOfToday().getFullYear(), 0, 0)) / 86400000);
  let index = dayOfYear % SECURITY_TIPS.length;
  const show = () => { text.textContent = SECURITY_TIPS[index]; };
  show();

  button.addEventListener("click", () => {
    index = (index + 1) % SECURITY_TIPS.length;
    show();
  });
}

/* ================== 6. FORM VALIDATION FRAMEWORK ================== */
const NAME_PATTERN = /^[A-Za-zÀ-ÖØ-öø-ÿ'’ -]{2,60}$/;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_PATTERN = /^(?:\+27|0)[1-9]\d{8}$/; // South African numbers, e.g. 0115550142 or +27115550142

const fieldValue = field => (field.type === "checkbox" ? field.checked : field.value.trim());

// Shows (or clears) an error message under a field and flags it for screen readers.
function setFieldError(field, message) {
  const error = document.getElementById(`${field.id}-error`);
  field.classList.toggle("invalid", Boolean(message));
  field.setAttribute("aria-invalid", message ? "true" : "false");
  if (error) error.textContent = message || "";
}

// Validates a field as the user leaves it, then keeps re-checking while they correct it.
function attachLiveValidation(rules) {
  Object.keys(rules).forEach(id => {
    const field = document.getElementById(id);
    if (!field) return;
    const check = () => setFieldError(field, rules[id](fieldValue(field), field));
    field.addEventListener("blur", () => { field.dataset.touched = "true"; check(); });
    ["input", "change"].forEach(type =>
      field.addEventListener(type, () => { if (field.dataset.touched) check(); }));
  });
}

// Validates every field on submit and returns how many are invalid.
function validateAll(rules) {
  let firstInvalid = null;
  let count = 0;
  Object.keys(rules).forEach(id => {
    const field = document.getElementById(id);
    if (!field) return;
    field.dataset.touched = "true";
    const message = rules[id](fieldValue(field), field);
    setFieldError(field, message);
    if (message) {
      count++;
      if (!firstInvalid) firstInvalid = field;
    }
  });
  return { count, firstInvalid };
}

function clearErrors(form) {
  $$("input, select, textarea", form).forEach(field => {
    setFieldError(field, "");
    delete field.dataset.touched;
  });
}

// Shared rules used by both forms.
const sharedRules = {
  name: value => !value ? "Please enter your full name."
    : !NAME_PATTERN.test(value) ? "Use letters, spaces, hyphens or apostrophes only (2 to 60 characters)." : "",
  email: value => !value ? "Please enter your email address."
    : !EMAIL_PATTERN.test(value) ? "Enter a valid email address, for example name@example.com." : "",
  phoneOptional: value => value && !PHONE_PATTERN.test(value.replace(/[\s\-()]/g, ""))
    ? "Enter a valid South African number, for example 011 555 0142 or +27 11 555 0142." : "",
  message: (value, min, max) => value.length < min ? `Please write at least ${min} characters so we can help properly.`
    : value.length > max ? `Please keep this to ${max} characters or fewer.` : ""
};

// Live "123 / 500" character counter under a textarea.
function attachCounter(textarea, counterId, max) {
  const counter = document.getElementById(counterId);
  if (!textarea || !counter) return () => {};
  const update = () => { counter.textContent = `${textarea.value.length} / ${max} characters`; };
  textarea.addEventListener("input", update);
  update();
  return update; // call again after a reset to refresh the number
}

/* ============ 7. ENQUIRY FORM: QUOTE + AVAILABILITY RESPONSE ============ */

// Fills the service drop-down from the data file and preselects ?service=... from the URL.
function initEnquirySelect() {
  const select = $("#enqService");
  if (!select || typeof SERVICES === "undefined") return;
  SERVICES.forEach(service => select.append(el("option", { text: service.name, attrs: { value: service.name } })));
  const requested = new URLSearchParams(location.search).get("service");
  if (requested && SERVICES.some(s => s.name === requested)) select.value = requested;
}

// Works out the price for a service. Returns each line so it can be displayed.
function calculateQuote(service, quantity, clientType, priority) {
  const extraUnits = Math.max(0, quantity - service.included);
  const subtotal = service.base + extraUnits * service.perUnit;
  const discount = subtotal * CLIENT_DISCOUNTS[clientType];
  const afterDiscount = subtotal - discount;
  const surcharge = priority ? afterDiscount * PRIORITY_SURCHARGE : 0;
  const exVat = afterDiscount + surcharge;
  const vat = exVat * VAT_RATE;
  return { extraUnits, subtotal, discount, surcharge, exVat, vat, total: exVat + vat };
}

// Works out the earliest start date and whether the preferred date is possible.
function calculateAvailability(service, priority, preferredDate) {
  const leadDays = priority ? Math.max(1, Math.ceil(service.leadDays / 2)) : service.leadDays;
  const earliest = addBusinessDays(startOfToday(), leadDays);
  if (!preferredDate) {
    return { earliest, ok: true, message: `The earliest we can start is ${longDate(earliest)}.` };
  }
  if (preferredDate >= earliest) {
    return { earliest, ok: true, message: `Good news: ${longDate(preferredDate)} is available.` };
  }
  return {
    earliest, ok: false,
    message: `${longDate(preferredDate)} is too soon for this service. The earliest available date is ${longDate(earliest)}.`
  };
}

function initEnquiryForm() {
  const form = $("#enquiryForm");
  if (!form || typeof SERVICES === "undefined") return;

  const service = $("#enqService");
  const quantity = $("#enqQuantity");
  const date = $("#enqDate");
  const message = $("#enqMessage");
  const summary = $("#enquirySummary");
  const result = $("#enquiryResult");

  // The preferred date must be after today, so set the calendar minimum.
  const tomorrow = new Date(startOfToday());
  tomorrow.setDate(tomorrow.getDate() + 1);
  date.min = toInputDate(tomorrow);

  // Tailor the quantity label to the chosen service (devices, participants, ...).
  function updateQuantityHint() {
    const chosen = SERVICES.find(s => s.name === service.value);
    if (!chosen) {
      $("#enqQuantityLabel").textContent = "Quantity *";
      $("#enqQuantityHint").textContent = "Choose a service first.";
      return;
    }
    $("#enqQuantityLabel").textContent = `Number of ${chosen.unitPlural} *`;
    $("#enqQuantityHint").textContent =
      `Base price includes ${chosen.included} ${chosen.included === 1 ? chosen.unitSingular : chosen.unitPlural}.`;
  }
  service.addEventListener("change", updateQuantityHint);
  updateQuantityHint();
  const updateCounter = attachCounter(message, "enqMessage-count", 500);

  const rules = {
    enqName: sharedRules.name,
    enqEmail: sharedRules.email,
    enqPhone: sharedRules.phoneOptional,
    enqService: value => value ? "" : "Please choose a service.",
    enqClient: value => value ? "" : "Please tell us what type of client you are.",
    enqQuantity: value => {
      const number = Number(value);
      if (!value) return "Please enter a quantity.";
      return Number.isInteger(number) && number >= 1 && number <= 500 ? "" : "Enter a whole number between 1 and 500.";
    },
    enqDate: value => {
      if (!value) return ""; // optional
      const chosen = parseDate(value);
      const limit = new Date(startOfToday());
      limit.setFullYear(limit.getFullYear() + 1);
      if (!chosen) return "Enter a valid date.";
      if (chosen <= startOfToday()) return "Please choose a date after today.";
      if (isWeekend(chosen)) return "We work Monday to Friday. Please pick a weekday.";
      if (chosen > limit) return "Please choose a date within the next 12 months.";
      return "";
    },
    enqMessage: value => sharedRules.message(value, 10, 500),
    enqConsent: checked => checked ? "" : "Please confirm before submitting."
  };
  attachLiveValidation(rules);

  form.addEventListener("submit", event => {
    event.preventDefault();
    const { count, firstInvalid } = validateAll(rules);

    if (count > 0) {
      summary.textContent = `Please fix the ${count} highlighted ${count === 1 ? "field" : "fields"} and try again.`;
      summary.className = "form-response error";
      result.hidden = true;
      firstInvalid.focus();
      return;
    }

    // --- Input is valid: process it and build the response ---
    const chosenService = SERVICES.find(s => s.name === service.value);
    const clientType = $("#enqClient").value;
    const priority = $("input[name='urgency']:checked").value === "priority";
    const preferred = parseDate(date.value);
    const quote = calculateQuote(chosenService, Number(quantity.value), clientType, priority);
    const availability = calculateAvailability(chosenService, priority, preferred);
    const reference = "ENQ-" + toInputDate(startOfToday()).replace(/-/g, "") + "-" + Math.floor(1000 + Math.random() * 9000);

    renderEnquiryResult({
      reference, name: $("#enqName").value.trim(), service: chosenService,
      quantity: Number(quantity.value), clientType, priority, quote, availability
    });

    form.reset();            // clear the fields first (the reset handler empties the summary)
    clearErrors(form);
    updateQuantityHint();
    updateCounter();
    summary.textContent = "Thank you. Your enquiry has been processed - see your estimate below.";
    summary.className = "form-response success";
    result.scrollIntoView({ behavior: "smooth", block: "start" });
    result.focus();
  });

  form.addEventListener("reset", () => {
    summary.textContent = "";
    summary.className = "form-response";
  });
}

// Displays the quote and availability using safe DOM methods.
function renderEnquiryResult(data) {
  const result = $("#enquiryResult");
  const { quote, service } = data;

  const row = (label, value, strong) => el("div", { class: strong ? "quote-row total" : "quote-row" },
    el("span", { text: label }), el("span", { text: value }));

  const unit = data.quantity === 1 ? service.unitSingular : service.unitPlural;
  const rows = [row(`${service.name} (base price)`, money(service.base))];
  if (quote.extraUnits > 0) rows.push(row(`${quote.extraUnits} extra ${quote.extraUnits === 1 ? service.unitSingular : service.unitPlural}`, money(quote.extraUnits * service.perUnit)));
  if (quote.discount > 0) rows.push(row(`${CLIENT_LABELS[data.clientType]} discount`, "-" + money(quote.discount)));
  if (quote.surcharge > 0) rows.push(row("Priority booking (+25%)", money(quote.surcharge)));
  rows.push(row("Subtotal (excl. VAT)", money(quote.exVat)));
  rows.push(row("VAT (15%)", money(quote.vat)));
  rows.push(row("Estimated total", money(quote.total), true));

  const availability = el("p", { class: data.availability.ok ? "availability ok" : "availability warn", text: data.availability.message });

  const again = el("button", { class: "btn btn-outline", text: "Start another enquiry", attrs: { type: "button" } });
  again.addEventListener("click", () => {
    result.hidden = true;
    $("#enquirySummary").textContent = "";
    $("#enquirySummary").className = "form-response";
    $("#enqName").focus();
  });

  result.replaceChildren(
    el("h2", { text: "Your estimate" }),
    el("p", { text: `Reference ${data.reference} for ${data.name}: ${data.quantity} ${unit}, ${CLIENT_LABELS[data.clientType].toLowerCase()}.` }),
    el("div", { class: "quote-table" }, ...rows),
    availability,
    el("p", { class: "fine-print", text: "This is an automatic estimate for the demonstration website. CipherVault is a fictional business, so nothing has been stored or sent." }),
    again
  );
  result.hidden = false;
}

/* ============ 8. CONTACT FORM: COMPILES AN EMAIL TO SEND ============ */
function initContactForm() {
  const form = $("#contactForm");
  if (!form) return;

  const summary = $("#contactSummary");
  const preview = $("#emailPreview");
  const message = $("#contactMessage");
  const updateCounter = attachCounter(message, "contactMessage-count", 1000);

  const rules = {
    contactName: sharedRules.name,
    contactEmail: sharedRules.email,
    contactPhone: sharedRules.phoneOptional,
    contactOffice: value => value ? "" : "Please choose which office should receive your message.",
    messageType: value => value ? "" : "Please choose a message type.",
    contactMessage: value => sharedRules.message(value, 10, 1000),
    contactConsent: checked => checked ? "" : "Please confirm before continuing."
  };
  attachLiveValidation(rules);

  form.addEventListener("submit", event => {
    event.preventDefault();
    const { count, firstInvalid } = validateAll(rules);

    if (count > 0) {
      summary.textContent = `Please fix the ${count} highlighted ${count === 1 ? "field" : "fields"} and try again.`;
      summary.className = "form-response error";
      preview.hidden = true;
      firstInvalid.focus();
      return;
    }

    // --- Input is valid: compile the email ---
    const office = $("#contactOffice").value;
    const type = $("#messageType").value;
    const name = $("#contactName").value.trim();
    const recipient = OFFICE_EMAILS[office];
    const subject = `[CipherVault website] ${type} from ${name}`;
    const phone = $("#contactPhone").value.trim() || "Not provided";
    const body = [
      `Hello CipherVault ${office} team,`,
      "",
      `Message type: ${type}`,
      `Name: ${name}`,
      `Email: ${$("#contactEmail").value.trim()}`,
      `Phone: ${phone}`,
      "",
      "Message:",
      message.value.trim(),
      "",
      "Sent from the CipherVault website contact form."
    ].join("\r\n");

    // mailto: opens the visitor's own email app with everything filled in.
    const mailto = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    renderEmailPreview({ recipient, subject, body, mailto });

    summary.textContent = "Your message is ready. Review the email below, then press Send email.";
    summary.className = "form-response success";
  });

  form.addEventListener("reset", () => {
    clearErrors(form);
    summary.textContent = "";
    summary.className = "form-response";
    preview.hidden = true;
    setTimeout(updateCounter); // runs after the browser has emptied the fields
  });
}

function renderEmailPreview({ recipient, subject, body, mailto }) {
  const preview = $("#emailPreview");

  const sendLink = el("a", { class: "btn btn-primary", text: "Send email", attrs: { href: mailto } });
  const copyButton = el("button", { class: "btn btn-outline", text: "Copy email text", attrs: { type: "button" } });
  copyButton.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(`To: ${recipient}\nSubject: ${subject}\n\n${body}`);
      copyButton.textContent = "Copied!";
    } catch (error) {
      copyButton.textContent = "Copy not available - select the text manually";
    }
    setTimeout(() => { copyButton.textContent = "Copy email text"; }, 2500);
  });
  const editButton = el("button", { class: "btn btn-outline", text: "Edit message", attrs: { type: "button" } });
  editButton.addEventListener("click", () => { preview.hidden = true; $("#contactMessage").focus(); });

  preview.replaceChildren(
    el("h3", { text: "Your email is ready" }),
    el("p", { class: "email-meta" }, el("strong", { text: "To: " }), document.createTextNode(recipient)),
    el("p", { class: "email-meta" }, el("strong", { text: "Subject: " }), document.createTextNode(subject)),
    el("pre", { class: "email-body", text: body }),
    el("div", { class: "card-actions" }, sendLink, copyButton, editButton),
    el("p", { class: "fine-print", text: "Pressing Send email opens your own email app with this message filled in. You then press send there." })
  );
  preview.hidden = false;
  preview.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

/* =================== 9. CONTACT PAGE: INTERACTIVE MAP =================== */
function initMap() {
  const mapElement = $("#map");
  if (!mapElement) return;

  // If the Leaflet library did not load (offline, blocked), the static image stays visible.
  if (typeof L === "undefined") return;

  try {
    const wrapper = mapElement.parentElement;
    wrapper.classList.add("map-ready");

    const map = L.map(mapElement, { scrollWheelZoom: false });
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    // Office data comes from the location cards in the HTML (data-* attributes).
    const markers = {};
    const bounds = [];
    $$(".location-card[data-lat]").forEach(card => {
      const lat = Number(card.dataset.lat);
      const lng = Number(card.dataset.lng);
      const name = card.dataset.name;
      const popup = el("div", {},
        el("strong", { text: `${name} Office` }),
        el("br"),
        document.createTextNode(card.dataset.area)
      );
      markers[name] = L.marker([lat, lng], { title: `${name} Office`, alt: `${name} Office` }).addTo(map).bindPopup(popup);
      bounds.push([lat, lng]);
    });
    map.fitBounds(bounds, { padding: [40, 40] });

    // Buttons fly to an office, or back out to show both.
    $$("[data-map-target]").forEach(button => {
      button.addEventListener("click", () => {
        const target = button.dataset.mapTarget;
        if (target === "all") {
          map.flyToBounds(bounds, { padding: [40, 40] });
          map.closePopup();
        } else if (markers[target]) {
          map.flyTo(markers[target].getLatLng(), 15);
          markers[target].openPopup();
        }
        mapElement.scrollIntoView({ behavior: "smooth", block: "center" });
      });
    });

    // Click or tap the map once to enable scroll-wheel zoom (avoids trapping page scroll).
    map.on("focus", () => map.scrollWheelZoom.enable());
    map.on("blur", () => map.scrollWheelZoom.disable());
  } catch (error) {
    console.warn("Map could not start; showing the static map image instead.", error);
    mapElement.parentElement.classList.remove("map-ready");
  }
}

/* ===================== 10. SCROLL REVEAL ANIMATION ===================== */
function initRevealOnScroll() {
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const targets = $$(".card:not(.service-card), .person, .location-card");
  if (reduceMotion || !("IntersectionObserver" in window) || !targets.length) return;

  targets.forEach(target => target.classList.add("reveal"));
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("reveal-in");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });
  targets.forEach(target => observer.observe(target));
}

/* ============================ START-UP ============================ */
document.addEventListener("DOMContentLoaded", () => {
  initNavigation();
  initServices();
  initEnquirySelect();
  initAccordions();
  initTabs();
  initGallery();
  initTip();
  initEnquiryForm();
  initContactForm();
  initMap();
  initRevealOnScroll();
});
